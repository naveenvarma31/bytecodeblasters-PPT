package com.hcl.project.careerguidance.pojo;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/*
 * This class is used to hold User details.
 */
public class User implements Serializable {

	/**
	 * Unique serial Version UID
	 */
	private static final long serialVersionUID = -1458546747652324485L;

	private String firstName;
	private String lastName;
	private String emailId;
	private String password;
	private String mobileNo;
	private String qualifiation;

	public User() {
	}

	public User(String firstName, String lastName, String emailId, String password, String mobileNo,
			String qualifiation) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.password = password;
		this.mobileNo = mobileNo;
		this.qualifiation = qualifiation;
	}


	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getQualifiation() {
		return qualifiation;
	}

	public void setQualifiation(String qualifiation) {
		this.qualifiation = qualifiation;
	}


}
