package com.hcl.project.careerguidance.helper;

/*
 *  This interface contains abstract competitiveExams() method
 *  for all types of competitive examinations. 
 */
public interface ICareer {

	void competitiveExams();
}
