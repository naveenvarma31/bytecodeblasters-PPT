package com.hcl.project.careerguidance.domain;

import com.hcl.project.careerguidance.helper.ICareer;

/*
 * This class contains Engineering job and competitive examination details.
 */
public class Engineering implements ICareer{

	@Override
	public void competitiveExams() {
		System.out.println(
				"* List of national Level Engineering Competetive Exams\r\n" + 
				"\r\n" + 
				"1.) Joint Entrance Examination(JEE) � Main\r\n" + 
				"2.) Joint Entrance Examination(JEE) � Advanced\r\n" + 
				"3.) Common Law Admission Test\r\n" + 
				"4.) National Eligibility cum Entrance Test (Undergraduate)(Postgraduate)\r\n" + 
				"5.) Common Admission TestCommon Entrance Examination for Design\r\n" + 
				"6.) Common Management Admission TestGraduate Aptitude Test in EngineeringJoint Admission Test to M.Sc.\r\n" + 
				"7.) National Eligibility Test\r\n" + 
				"8.) National Entrance Screening Test\r\n" + 
				"9.) NIT MCA Common Entrance TestPolicy Aptitude Test\r\n" + 
			   "10.) Management Aptitude Test\r\n" + 
				"\r\n" + 
				"* List of State Level Engineering Competative Exams\r\n" + 
				"\r\n" + 
				"1.) Engineering Agricultural and Medical Common Entrance Test\r\n" + 
				"2.) Joint Entrance Examination (JEE)\r\n" + 
				"3.) Kerala Engineering Agricultural Medical\r\n" + 
				"4.) Graduate Aptitude Test in Engineering (GATE)\r\n" + 
				"5.) Odisha Joint Entrance Examination\r\n" + 
				"6.) Rajasthan Pre-Engineering Test (RPET) / Rajasthan Engineering Admission Process (REAP)\r\n" + 
				"7.) Birla Institute of Technology and Science Admission Test\r\n" + 
				"8.) Tamil Nadu Engineering Admission\r\n" + 
				"9.) WBJEE\r\n" + 
			   "10.) Consortium of Medical, Engineering and Dental Colleges of Karnataka(COMED-K)");
		
	}
	
	
	
	
	
	

}
